﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        grpFloorOccupancyData = New GroupBox()
        lstResults = New ListBox()
        lblInstructions = New Label()
        Label2 = New Label()
        btnCompleteReport = New Button()
        btnClear = New Button()
        btnExit = New Button()
        txtRoomsOccupied = New TextBox()
        txtOccupancyRate = New TextBox()
        grpFloorOccupancyData.SuspendLayout()
        SuspendLayout()
        ' 
        ' grpFloorOccupancyData
        ' 
        grpFloorOccupancyData.Controls.Add(lstResults)
        grpFloorOccupancyData.Font = New Font("MingLiU-ExtB", 12F, FontStyle.Bold, GraphicsUnit.Point)
        grpFloorOccupancyData.Location = New Point(21, 38)
        grpFloorOccupancyData.Margin = New Padding(5, 1, 5, 1)
        grpFloorOccupancyData.Name = "grpFloorOccupancyData"
        grpFloorOccupancyData.Padding = New Padding(5, 1, 5, 1)
        grpFloorOccupancyData.Size = New Size(715, 245)
        grpFloorOccupancyData.TabIndex = 0
        grpFloorOccupancyData.TabStop = False
        grpFloorOccupancyData.Text = "Floor Occupancy Data"
        ' 
        ' lstResults
        ' 
        lstResults.Font = New Font("Consolas", 12F, FontStyle.Regular, GraphicsUnit.Point)
        lstResults.FormattingEnabled = True
        lstResults.ItemHeight = 19
        lstResults.Location = New Point(19, 42)
        lstResults.Name = "lstResults"
        lstResults.Size = New Size(679, 175)
        lstResults.TabIndex = 0
        ' 
        ' lblInstructions
        ' 
        lblInstructions.AutoSize = True
        lblInstructions.Font = New Font("MingLiU-ExtB", 12F, FontStyle.Bold, GraphicsUnit.Point)
        lblInstructions.Location = New Point(157, 320)
        lblInstructions.Margin = New Padding(5, 0, 5, 0)
        lblInstructions.Name = "lblInstructions"
        lblInstructions.Size = New Size(241, 16)
        lblInstructions.TabIndex = 1
        lblInstructions.Text = "Enter Total Rooms Occupied"
        ' 
        ' Label2
        ' 
        Label2.AutoSize = True
        Label2.Font = New Font("MingLiU-ExtB", 12F, FontStyle.Bold, GraphicsUnit.Point)
        Label2.Location = New Point(157, 397)
        Label2.Margin = New Padding(5, 0, 5, 0)
        Label2.Name = "Label2"
        Label2.Size = New Size(205, 16)
        Label2.TabIndex = 2
        Label2.Text = "Overall Occupancy Rate"
        ' 
        ' btnCompleteReport
        ' 
        btnCompleteReport.Location = New Point(181, 469)
        btnCompleteReport.Margin = New Padding(5, 1, 5, 1)
        btnCompleteReport.Name = "btnCompleteReport"
        btnCompleteReport.Size = New Size(80, 51)
        btnCompleteReport.TabIndex = 3
        btnCompleteReport.Text = "Complete Report"
        btnCompleteReport.UseVisualStyleBackColor = True
        ' 
        ' btnClear
        ' 
        btnClear.Location = New Point(312, 469)
        btnClear.Margin = New Padding(5, 1, 5, 1)
        btnClear.Name = "btnClear"
        btnClear.Size = New Size(80, 51)
        btnClear.TabIndex = 4
        btnClear.Text = "Clear"
        btnClear.UseVisualStyleBackColor = True
        ' 
        ' btnExit
        ' 
        btnExit.Location = New Point(445, 469)
        btnExit.Margin = New Padding(5, 1, 5, 1)
        btnExit.Name = "btnExit"
        btnExit.Size = New Size(80, 51)
        btnExit.TabIndex = 5
        btnExit.Text = "Exit"
        btnExit.UseVisualStyleBackColor = True
        ' 
        ' txtRoomsOccupied
        ' 
        txtRoomsOccupied.Location = New Point(421, 314)
        txtRoomsOccupied.Name = "txtRoomsOccupied"
        txtRoomsOccupied.ReadOnly = True
        txtRoomsOccupied.Size = New Size(81, 27)
        txtRoomsOccupied.TabIndex = 6
        ' 
        ' txtOccupancyRate
        ' 
        txtOccupancyRate.Location = New Point(421, 390)
        txtOccupancyRate.Name = "txtOccupancyRate"
        txtOccupancyRate.ReadOnly = True
        txtOccupancyRate.Size = New Size(81, 27)
        txtOccupancyRate.TabIndex = 7
        ' 
        ' Form1
        ' 
        AutoScaleDimensions = New SizeF(8F, 16F)
        AutoScaleMode = AutoScaleMode.Font
        BackgroundImage = My.Resources.Resources.hotelRoomImg1Re3
        ClientSize = New Size(771, 554)
        Controls.Add(txtOccupancyRate)
        Controls.Add(txtRoomsOccupied)
        Controls.Add(btnExit)
        Controls.Add(btnClear)
        Controls.Add(btnCompleteReport)
        Controls.Add(Label2)
        Controls.Add(lblInstructions)
        Controls.Add(grpFloorOccupancyData)
        Font = New Font("MingLiU_HKSCS-ExtB", 12F, FontStyle.Regular, GraphicsUnit.Point)
        Margin = New Padding(5, 1, 5, 1)
        Name = "Form1"
        Text = "Hotel Occupancy"
        grpFloorOccupancyData.ResumeLayout(False)
        ResumeLayout(False)
        PerformLayout()
    End Sub

    Friend WithEvents grpFloorOccupancyData As GroupBox
    Friend WithEvents lblInstructions As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents btnCompleteReport As Button
    Friend WithEvents btnClear As Button
    Friend WithEvents btnExit As Button
    Friend WithEvents lstResults As ListBox
    Friend WithEvents txtRoomsOccupied As TextBox
    Friend WithEvents txtOccupancyRate As TextBox
End Class
