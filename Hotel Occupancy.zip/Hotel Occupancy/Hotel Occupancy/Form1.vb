﻿Imports System.ComponentModel


Public Class Form1
    Dim totalRooms As Integer = 240
    Dim totalOccupied As Integer = 0
    Dim overallOccupancyRate As Double
    Dim occupiedRooms As Integer
    Private Sub btnCompleteReport_Click(sender As Object, e As EventArgs) Handles btnCompleteReport.Click


        'Clear previous results
        lstResults.Items.Clear()
        txtOccupancyRate.Clear()

        'Iterate through each floor (8)
        For floor As Integer = 1 To 8
            'skip 13th floor
            If floor = 13 Then Continue For

            'input validation loop for occupied rooms (1 to 30)
            Do
                occupiedRooms = InputBox("Enter number of rooms occupied on Floor" & floor.ToString(), "Occupancy Input")
            Loop Until occupiedRooms >= 1 AndAlso occupiedRooms <= 30

            'calculate and display occupancy rate for the floor
            Dim occupancyRate As Double = (occupiedRooms / 30) * 100
            lstResults.Items.Add("Floor " & floor.ToString() & ": " & occupancyRate.ToString("0.00") & "%")

            'Accumulate total occupied rooms
            totalOccupied += occupiedRooms
        Next

        'Calculate overall occupancy rate
        overallOccupancyRate = (totalOccupied / totalRooms) * 100
        txtOccupancyRate.Text = overallOccupancyRate.ToString("0.00") & "%"

        'Display the total rooms occupied in the txt
        txtRoomsOccupied.Text = totalOccupied.ToString()


    End Sub


    Private Sub btnClear_Click(sender As Object, e As EventArgs) Handles btnClear.Click
        For floor As Integer = 1 To 8
            Dim txtBox As TextBox = Me.Controls.Find("txtFloor" & floor.ToString(), True).FirstOrDefault()
            If txtBox IsNot Nothing Then
                txtBox.Clear()
            End If
        Next

        lstResults.Items.Clear()
        txtOccupancyRate.Clear()
        txtRoomsOccupied.Clear()


    End Sub

    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Me.Close()
    End Sub
End Class
